### Hexlet tests and linter status:
[![Actions Status](https://github.com/zhukata/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/zhukata/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/2655f98ca4819a95d0c1/maintainability)](https://codeclimate.com/github/zhukata/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/AfVsYcjU7xUKegEWiGou6vC8Z.svg)](https://asciinema.org/a/AfVsYcjU7xUKegEWiGou6vC8Z)
[![asciicast](https://asciinema.org/a/oKxrzfGC3DJrTQCwZzT2dS9lb.svg)](https://asciinema.org/a/oKxrzfGC3DJrTQCwZzT2dS9lb)